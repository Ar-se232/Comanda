# команда майнкрафт 2

A Pen created on CodePen.

Original URL: [https://codepen.io/xctzsljo-the-bashful/pen/pvooaPZ](https://codepen.io/xctzsljo-the-bashful/pen/pvooaPZ).

